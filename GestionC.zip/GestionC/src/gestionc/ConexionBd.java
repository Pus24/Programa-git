package gestionc;

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

// @author Pedro Lopez R

public class ConexionBd {

    Connection cn;
    PreparedStatement ps;
    ResultSet rs;

    public ConexionBd() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdconexion", "root", "");
            System.out.println("Conexion Exitosa");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al Conectarse" + e);
        }

    }

    public int Repaciente(String nombre, String apellidos, String telefono, String direccion, String correo) {
        int res = 0;
        try {
            ps = cn.prepareStatement("INSERT INTO paciente (nombre, apellidos, telefono, direccion, correo) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, nombre);
            ps.setString(2, apellidos);
            ps.setString(3, telefono);
            ps.setString(4, direccion);
            ps.setString(5, correo);
            res = ps.executeUpdate();
            System.out.println("Registro Exitoso");

        } catch (SQLException e) {
            System.out.println("Error al Registrarse" + e);
        }
        return res;
    }


    public int Actpaciente(String nombre, String apellidos, String telefono, String direccion, String correo, String id) {
        int res = 0;
        try {
            ps = cn.prepareStatement("UPDATE paciente SET nombre=?, apellidos=?, telefono=?, direccion=?, correo=? WHERE id=?");
            ps.setString(1, nombre);
            ps.setString(2, apellidos);
            ps.setString(3, telefono);
            ps.setString(4, direccion);
            ps.setString(5, correo);
            ps.setString(6, id);
            res = ps.executeUpdate();
            System.out.println("Actualización Exitosa");
        } catch (SQLException e) {
            System.out.println("Error al Actualizar: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar los recursos: " + e.getMessage());
            }
        }
        return res;
    }

    public int Deletepaciente(String id) {
        int res = 0;
        try {
            ps = cn.prepareStatement("DELETE from paciente WHERE id=?");
            ps.setString(1, id);
            res = ps.executeUpdate();
            System.out.println("Eliminado Exitosamente");
        } catch (SQLException e) {
            System.out.println("Error al Eliminar: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar los recursos: " + e.getMessage());
            }
        }
        return res;
    }
    
    public ArrayList<ListadePacientes> ListarPacientes() {
        ArrayList<ListadePacientes> res=new  ArrayList<>();
        
        try {
            ps=cn.prepareStatement("select * from paciente");
            rs=ps.executeQuery();
            while (rs.next()) {
                ListadePacientes paciente=new  ListadePacientes();
                paciente.setId(rs.getString("id"));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setApellidos(rs.getString("apellidos"));
                paciente.setTelefono(rs.getString("telefono"));
                paciente.setDireccion(rs.getString("direccion"));
                paciente.setCorreo(rs.getString("correo"));
                res.add(paciente);
                
            }
        } catch (Exception e) {
        } finally {
        }
        return res;
        
    }
    
}
